



const Admin = () =>{
    return(
        <div className="">
            <h1>Admin Pannel</h1>
        </div>
        
    )
}
export default Admin;